#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "types.h"


void fib(int n) {
	if (n <= 1)
		return;
	fib(n-1);
	fib(n-2);
}

int main() {
        
        policy(0);
        int pid1;
        pid1 = fork();
    
        if (pid1==0)
        {
          priority(100); 
          while(1)
          {
            printf(2,"process %d : ***111*** \n",getpid());
          }
          
          exit(0);
        }
        int pid2;
        pid2 = fork();
        if (pid2==0)
        {
                    while(1)
          {
            printf(2,"process %d : ***222*** \n",getpid());
          }
          exit(0);
        }
        
        int pid3;
        pid3 = fork();
        if (pid3==0)
        {
                    while(1)
          {
            printf(2,"process %d : ***333*** \n",getpid());
          }
          exit(0);
        }
    
        int pid4;
        pid4 = fork();
        if (pid4==0)
        {
                    while(1)
          {
            printf(2,"process %d : ***444*** \n",getpid());
          }
          exit(0);
        }
        
        int pid5;
        pid5 = fork();
        if (pid5==0)
        {
                    while(1)
          {
            printf(2,"process %d : ***555*** \n",getpid());
          }
          exit(0);
        }

        int pid6;
        pid6 = fork();
        if (pid6==0)
        {
                    while(1)
          {
            printf(2,"process %d : ***666*** \n",getpid());
          }
          exit(0);
        }
        
        //int status1;
        //int status2;
        //wait(&status1);
        //printf(1,"%d awaken after son %d returned\n",getpid(),status1);
        //wait(&status2);
        //printf(1,"%d awaken after son %d returned\n",getpid(),status2);
        //printf(1, "done all commands main is over!!!\n");
	
}