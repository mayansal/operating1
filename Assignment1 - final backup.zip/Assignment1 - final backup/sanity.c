#include "types.h"
#include "user.h"
struct perf {
int ctime;
int ttime;
int stime;
int retime;
int rutime;
};

void fib(int n) {
    if (n <= 1)
        return;
    fib(n-1);
    fib(n-2);
}

int main() {
    int i, pid, status;
    int pnum = 15;
    struct perf performance;
    int totalTurnaroundTime;
    int totalReadyTime;


    //policy(0)*********************************************************************************/
    for(i = 0; i<pnum; i++){
        if(fork() == 0){
            if(i < 10){
                fib(35);
            }
            else{
                sleep(200);
            }
            exit(0);  
        }
        //father continue
    }
    printf(1,"\n**********************POLICY: Uniform time distribution**********************\n");
    printf(1,"Details for every process:\n");
    totalTurnaroundTime = 0;
    totalReadyTime = 0;
    for(i = 0; i < pnum; i++){
         pid = wait_stat(&status, (struct perf*)&performance);
         printf(1, "pid: %d ", pid);
         int ctime = ((struct perf*)&performance)->ctime;
         int ttime = ((struct perf*)&performance)->ttime;
         int stime = ((struct perf*)&performance)->stime;
         int retime = ((struct perf*)&performance)->retime;
         int rutime = ((struct perf*)&performance)->rutime;
         int turnaroundTime =  ttime-ctime;
         totalTurnaroundTime = totalTurnaroundTime + turnaroundTime;
         totalReadyTime = totalReadyTime + retime;
         printf(1, "ctime: %d ", ctime);
         printf(1, "ttime: %d ", ttime);
         printf(1, "stime: %d ", stime);
         printf(1, "retime: %d ", retime);
         printf(1, "rutime: %d ", rutime);
         printf(1, "turnaround time: %d\n", turnaroundTime);
    }
    printf(1,"Summary:\n");
    printf(1, "total turnaround time: %d\n", totalTurnaroundTime/pnum);
    printf(1, "total waiting (ready) time: %d\n", totalReadyTime/pnum);


    //policy(1)*********************************************************************************/
    policy(1);
    for(i = 0; i<pnum; i++){
        if(fork() == 0){
            if(i<5 || i>pnum-5){
                priority(100);
            }
            if(i < 10){
                fib(35);
            }
            else{
                sleep(200);
            }
            exit(0);  
        }
        //father continue
    }
    printf(1,"\n**********************POLICY: Priority scheduling******************************\n");
    printf(1,"Details for every process:\n");
    totalTurnaroundTime = 0;
    totalReadyTime = 0;
    for(i = 0; i < pnum; i++){
         pid = wait_stat(&status, (struct perf*)&performance);
         printf(1, "pid: %d ", pid);
         int ctime = ((struct perf*)&performance)->ctime;
         int ttime = ((struct perf*)&performance)->ttime;
         int stime = ((struct perf*)&performance)->stime;
         int retime = ((struct perf*)&performance)->retime;
         int rutime = ((struct perf*)&performance)->rutime;
         int turnaroundTime =  ttime-ctime;
         totalTurnaroundTime = totalTurnaroundTime + turnaroundTime;
         totalReadyTime = totalReadyTime + retime;
         printf(1, "ctime: %d ", ctime);
         printf(1, "ttime: %d ", ttime);
         printf(1, "stime: %d ", stime);
         printf(1, "retime: %d ", retime);
         printf(1, "rutime: %d ", rutime);
         printf(1, "turnaround time: %d\n", turnaroundTime);
    }
    printf(1,"Summary:\n");
    printf(1, "total turnaround time: %d\n", totalTurnaroundTime/pnum);
    printf(1, "total waiting (ready) time: %d\n", totalReadyTime/pnum);


    //policy(2)*********************************************************************************/
    policy(2);
    for(i = 0; i<pnum; i++){
        if(fork() == 0){
            if(i < 10){
                fib(35);
            }
            else{
                sleep(200);
            }
            exit(0);  
        }
        //father continue
    }
    printf(1,"\n**********************POLICY: Dynamic tickets allocation**************************\n");
    printf(1,"Details for every process:\n");
    totalTurnaroundTime = 0;
    totalReadyTime = 0;
    for(i = 0; i < pnum; i++){
         pid = wait_stat(&status, (struct perf*)&performance);
         printf(1, "pid: %d ", pid);
         int ctime = ((struct perf*)&performance)->ctime;
         int ttime = ((struct perf*)&performance)->ttime;
         int stime = ((struct perf*)&performance)->stime;
         int retime = ((struct perf*)&performance)->retime;
         int rutime = ((struct perf*)&performance)->rutime;
         int turnaroundTime =  ttime-ctime;
         totalTurnaroundTime = totalTurnaroundTime + turnaroundTime;
         totalReadyTime = totalReadyTime + retime;
         printf(1, "ctime: %d ", ctime);
         printf(1, "ttime: %d ", ttime);
         printf(1, "stime: %d ", stime);
         printf(1, "retime: %d ", retime);
         printf(1, "rutime: %d ", rutime);
         printf(1, "turnaround time: %d\n", turnaroundTime);
    }
    printf(1,"Summary:\n");
    printf(1, "total turnaround time: %d\n", totalTurnaroundTime/pnum);
    printf(1, "total waiting (ready) time: %d\n", totalReadyTime/pnum);

 }
    

