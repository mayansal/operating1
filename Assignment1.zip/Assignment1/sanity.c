#include "types.h"
#include "user.h"
struct perf {
int ctime;
int ttime;
int stime;
int retime;
int rutime;
};

void fib(int n) {
    if (n <= 1)
        return;
    fib(n-1);
    fib(n-2);
}

int main() {
    int status;
    struct perf  performance;
    int pid;
    if ((pid = fork()) >0) {
      wait_stat(&status, (struct perf*)&performance);
       printf(1, "pid: %d\n", pid);
       printf(1, "ctime: %d\n", ((struct perf*)&performance)->ctime);
       printf(1, "ttime: %d\n", ((struct perf*)&performance)->ttime);
       printf(1, "stime: %d\n", ((struct perf*)&performance)->stime);
       printf(1, "retime: %d\n", ((struct perf*)&performance)->retime);
       printf(1, "rutime: %d\n", ((struct perf*)&performance)->rutime);
        if (status != 137) {
            printf(1, "Fail\n");
        } else {
            printf(1, "Passed\n");
        }     
        exit(0);
    } else {
        fib(20);
        exit(137);
    }
}
    

